#!/sbin/sh
busybox mount -o rw,remount,rw /system
busybox find /system/app -type f -name '*.odex' -delete
busybox find /system/app -type f -name '*.art' -delete
busybox find /system/app -type f -name '*.odex.xz' -delete
busybox find /system/app -type f -name '*.art.xz' -delete

busybox find /system/priv-app -type f -name '*.odex' -delete
busybox find /system/priv-app -type f -name '*.art' -delete
busybox find /system/priv-app -type f -name '*.odex.xz' -delete
busybox find /system/priv-app -type f -name '*.art.xz' -delete

busybox find /system/framework -type f -name '*.odex' -delete
busybox find /system/framework -type f -name '*.art' -delete
busybox find /system/framework -type f -name '*.odex.xz' -delete
busybox find /system/framework -type f -name '*.art.xz' -delete
busybox find /system/framework -type f -name '*.oat' -delete

rm -f /system/odex.app.sqsh
rm -f /system/odex.priv-app.sqsh
exit 0
