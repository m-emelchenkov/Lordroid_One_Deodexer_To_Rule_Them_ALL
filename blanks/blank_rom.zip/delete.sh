#!/sbin/sh


rm -rf /system/app/*.odex
rm -rf /system/app/*.art
rm -rf /system/app/*.odex.xz
rm -rf /system/app/*.art.xz

rm -rf /system/framework/*.odex.xz
rm -rf /system/framework/*.art.xz
rm -rf /system/framework/*.odex
rm -rf /system/framework/*.oat
rm -rf /system/framework/*.art

rm -rf /system/priv-app/*.odex
rm -rf /system/priv-app/*.art
rm -rf /system/priv-app/*.odex.xz
rm -rf /system/priv-app/*.art.xz
exit 0
